import {React} from "react"
import { useContext } from "react"
import { CartContext } from "../context/cart.context"
import "./chekout.styles.scss"

const CheckOut =()=> {
    const {cartItems, addItemToCart, removeItemToCart} = useContext(CartContext)
    return (
        <div>
           {
            cartItems.map((cartItem) => {
                const {id, name, quantity} = cartItem;
                return (
                    <div key={id}>
                    <h2>{name}</h2>
                    <span>{quantity}</span>
                    <br />
                    <span onClick={()=> addItemToCart(cartItem)}>add</span>
                    <br />
                    <span>zero</span>
                    <br />
                    <span onClick={()=> removeItemToCart(cartItem)}>remove</span>
                </div>
                )
            })
           }
        </div>
    )
}


export default CheckOut;