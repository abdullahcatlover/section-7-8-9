import {React} from "react"
import "./chekout.styles.scss"

const CheckOut =()=> {
    return (
        <div>
            I am checkout page
        </div>
    )
}


export default CheckOut;